# MOBIMORY 1.0.6.10-dev – Block 1 UI-Testbuild

Dieser Build ordnet Block 1 so, dass Route, ETA und Wetter im realen Skipper-/Fahrerablauf testbar sind.

## Neu / korrigiert
- Der ausgewählte bzw. aktuelle Routenabschnitt steht oben in einer gemeinsamen Arbeitsfläche.
- Jeder Abschnitt hat einen eindeutigen **Öffnen**-Button.
- Direkt darunter erscheint eine **Streckenkarte** mit GPX-Linie, Start, Ziel und Wetterpunkten; während der Nutzung zusätzlich die reale GPS-Position.
- Primär wird OpenStreetMap über Leaflet verwendet. Wenn Kartenbibliothek oder Tiles nicht geladen werden können, erscheint automatisch eine lokale GPX-Routengrafik als Fallback.
- Die **Vorstart-Wettervorschau** sitzt direkt unter der Karte und ist auch bei einer bereits aktiven Nutzung testbar. Eine fiktive Startzeit verändert die reale Fahrt nicht.
- In aktiver Nutzung gibt es **Zurück zu Live**.
- GPX-Import, Abschnittsliste, Wetterregel und optionale Grobroute sind logisch gruppiert und nicht mehr als verstreute Großflächen angeordnet.
- Ein Routenabschnitt kann auch **manuell** mit Start- und Zielkoordinate angelegt werden.
- Zusätzliche **manuelle Wegpunkte** können einem geöffneten Abschnitt hinzugefügt sowie benannte Punkte bearbeitet werden.
- MOBIMORY bleibt ausdrücklich kein Routingprogramm. Bei Abweichung bleibt es beim Hinweis: **Bitte Route/Kurs überprüfen.**

## Installation
Den gesamten Inhalt dieses Ordners in das bestehende MOBIMORY-Repository hochladen und gleichnamige Dateien ersetzen.

Für 1.0.6.10 ist **keine neue SharePoint-Liste und kein neues Feld** gegenüber 1.0.6.9 erforderlich. Wenn die 1.0.6.9-Struktur bereits erfolgreich angelegt wurde, muss das Microsoft-365-Setup nicht erneut ausgeführt werden.
