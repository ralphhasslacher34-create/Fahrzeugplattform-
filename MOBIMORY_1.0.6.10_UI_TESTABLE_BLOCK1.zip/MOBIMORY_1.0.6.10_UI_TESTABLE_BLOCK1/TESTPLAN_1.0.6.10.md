# Kurztest 1.0.6.10

1. Planung & Historie öffnen und die Nutzung mit dem bereits importierten GPX-Abschnitt öffnen.
2. Direkt unter der Nutzungsübersicht muss **Planung · Route & Wetter** erscheinen.
3. Der gewählte Abschnitt muss oben sichtbar sein; darunter muss die Streckenkarte erscheinen.
4. In **Routenabschnitte** einen anderen Abschnitt mit **Öffnen** auswählen und prüfen, ob Karte und Wetterdaten wechseln.
5. Unter der Karte fiktive Startzeit wählen, **Wetter berechnen**, danach -1 h / +1 h testen.
6. Wetterregel Strecke/Zeit ändern und speichern; Vorschau muss neu berechnet werden.
7. Optional **+ Wegpunkt manuell hinzufügen** testen.
8. Bei aktiver Nutzung Cockpit öffnen: GPS-Speedometer muss direkt vor **Unterwegs · Route & Wetter** stehen.
9. In aktiver Nutzung eine fiktive Wettervorschau rechnen und danach **Zurück zu Live** wählen.
10. Es darf keine Navigations- oder Kurskorrekturanweisung erscheinen; nur **Bitte Route/Kurs überprüfen.**
