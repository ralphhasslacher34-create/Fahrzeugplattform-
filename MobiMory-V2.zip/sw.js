/* Offline-Betrieb: Die App-Dateien werden beim ersten Besuch gemerkt. */
importScripts('js/version.js');

var CACHE = 'mobimory-v2-' + self.MM.VERSION;
var DATEIEN = [
  './', 'index.html', 'manifest.webmanifest',
  'css/styles.css', 'icons/icon.svg',
  'js/version.js', 'js/fahrzeugarten.js', 'js/speicher.js', 'js/hilfen.js',
  'js/daten.js', 'js/ansicht.js', 'js/start.js'
];

self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(CACHE).then(function (c) { return c.addAll(DATEIEN); }).then(function () { return self.skipWaiting(); }));
});

self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (namen) {
    return Promise.all(namen.filter(function (n) { return n !== CACHE; }).map(function (n) { return caches.delete(n); }));
  }).then(function () { return self.clients.claim(); }));
});

self.addEventListener('fetch', function (e) {
  if (e.request.method !== 'GET') return;
  e.respondWith(caches.match(e.request).then(function (treffer) {
    return treffer || fetch(e.request).catch(function () {
      if (e.request.mode === 'navigate') return caches.match('index.html');
    });
  }));
});
