# Änderungen

## 2.0.1 – Schritt 1
- Neu aufgebaut, nicht aus V1 geflickt.
- Fahrzeugliste mit Kennung (Schale 1) und äußere Hülle (Schale 2).
- Sieben feste Fahrzeugarten: Auto, Motorrad, Wohnmobil, Wohnwagen, Oldtimer, Boot, Flugzeug. Felder je nach Art, zum Beispiel Tiefgang nur beim Boot, Achsen nur an Land.
- Handeingabe mit Prüfung. Änderungen werden als neuer Eintrag „Korrektur zu …“ gespeichert, der alte Stand bleibt im Verlauf.
- Offline-fähig, Daten liegen lokal auf dem Gerät.
- Automatische Tests für die Daten-Schicht.
