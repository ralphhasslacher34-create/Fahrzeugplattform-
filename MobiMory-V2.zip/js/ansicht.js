/*
 * Ansicht: was der Nutzer sieht.
 *
 * Seiten (Adresse hinter dem #):
 *   #/                         Meine Fahrzeuge (Schale 1)
 *   #/neu                      Fahrzeug anlegen
 *   #/fahrzeug/<id>            Fahrzeug mit äußerer Hülle (Schale 2)
 *   #/fahrzeug/<id>/aendern    Angaben ändern
 *
 * Alle Texte kommen mit textContent in die Seite, nie als HTML.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  var doc = global.document;

  var daten = null;
  var wurzel = null;
  var meldung = null; /* wird einmal auf der nächsten Seite gezeigt */

  /* ---------- kleine Bauhelfer ---------- */
  function anhaengen(el, kind) {
    if (kind === null || kind === undefined || kind === false) return;
    if (Array.isArray(kind)) { kind.forEach(function (k) { anhaengen(el, k); }); return; }
    if (typeof kind === 'string' || typeof kind === 'number') { el.appendChild(doc.createTextNode(String(kind))); return; }
    el.appendChild(kind);
  }
  function h(tag, attrs) {
    var el = doc.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        var v = attrs[k];
        if (v === null || v === undefined || v === false) return;
        if (k === 'text') el.textContent = v;
        else if (k.slice(0, 2) === 'on') el.addEventListener(k.slice(2), v);
        else if (k === 'value') el.value = v;
        else el.setAttribute(k, v === true ? '' : v);
      });
    }
    for (var i = 2; i < arguments.length; i++) anhaengen(el, arguments[i]);
    return el;
  }

  function markeSvg() {
    var ns = 'http://www.w3.org/2000/svg';
    var svg = doc.createElementNS(ns, 'svg');
    svg.setAttribute('viewBox', '0 0 32 32');
    svg.setAttribute('class', 'marke');
    svg.setAttribute('aria-hidden', 'true');
    [[2, 2, 28, '#ffffff'], [8, 8, 16, '#46bcc6']].forEach(function (r) {
      var e = doc.createElementNS(ns, 'rect');
      e.setAttribute('x', r[0]); e.setAttribute('y', r[1]);
      e.setAttribute('width', r[2]); e.setAttribute('height', r[2]);
      e.setAttribute('rx', r[2] / 4); e.setAttribute('fill', 'none');
      e.setAttribute('stroke', r[3]); e.setAttribute('stroke-width', 2.4);
      svg.appendChild(e);
    });
    var k = doc.createElementNS(ns, 'rect');
    k.setAttribute('x', 13); k.setAttribute('y', 13); k.setAttribute('width', 6); k.setAttribute('height', 6);
    k.setAttribute('rx', 1.5); k.setAttribute('fill', '#ffffff');
    svg.appendChild(k);
    return svg;
  }

  function kopf() {
    return h('header', { class: 'kopf' },
      h('a', { href: '#/' }, markeSvg(), 'MobiMory'),
      h('span', { class: 'version', text: 'Version ' + MM.VERSION }));
  }

  function fuss() {
    return h('footer', { class: 'fuss' },
      h('p', { text: 'Deine Daten liegen nur auf diesem Gerät. Eine automatische Sicherung gibt es in dieser Stufe noch nicht: Geht das Gerät kaputt, sind die Daten weg.' }),
      h('details', null,
        h('summary', { text: 'Nur für Tests' }),
        h('p', { text: 'Löscht alle Fahrzeuge auf diesem Gerät. Das lässt sich nicht rückgängig machen.' }),
        h('button', { class: 'knopf gefahr', type: 'button', text: 'Alle Daten auf diesem Gerät löschen',
          onclick: function () {
            if (global.confirm('Wirklich alle Daten auf diesem Gerät löschen?')) {
              daten.allesLoeschen().then(function () { meldung = 'Alle Daten auf diesem Gerät wurden gelöscht.'; global.location.hash = '#/'; zeige(); });
            }
          } })));
  }

  function seite(titel, inhalt, leiste) {
    doc.title = titel + ' – MobiMory';
    wurzel.textContent = '';
    var main = h('main', { class: 'inhalt', id: 'inhalt' });
    if (meldung) { main.appendChild(h('p', { class: 'meldung', role: 'status', text: meldung })); meldung = null; }
    anhaengen(main, inhalt);
    wurzel.appendChild(kopf());
    wurzel.appendChild(main);
    wurzel.appendChild(fuss());
    if (leiste) wurzel.appendChild(leiste);
    var h1 = main.querySelector('h1');
    if (h1) { h1.setAttribute('tabindex', '-1'); h1.focus({ preventScroll: true }); }
    global.scrollTo(0, 0);
  }

  function schild(artId, kennung) {
    var a = MM.Fahrzeugarten.art(artId);
    if (!kennung) return h('span', { class: 'schild leer', text: 'ohne Kennung' });
    return h('span', { class: 'schild welt-' + a.welt, text: kennung });
  }
  function kennungVon(artId, werte) { return werte[MM.Fahrzeugarten.kennungFeld(artId)] || ''; }

  /* ---------- Seite: Meine Fahrzeuge ---------- */
  function seiteListe() {
    return daten.fahrzeugListe().then(function (liste) {
      var inhalt = [h('h1', { text: 'Meine Fahrzeuge' })];
      if (!liste.length) {
        inhalt.push(h('div', { class: 'leer-hinweis' },
          h('p', { text: 'Hier ist noch kein Fahrzeug.' }),
          h('p', { text: 'Lege dein erstes Fahrzeug an. Es genügt zuerst die Bezeichnung und die Fahrzeugart. Alles andere kannst du jederzeit nachtragen.' })));
      } else {
        inhalt.push(h('ul', { class: 'liste' }, liste.map(function (x) {
          var a = MM.Fahrzeugarten.art(x.fahrzeug.art);
          return h('li', null, h('a', { class: 'zeile welt-' + a.welt, href: '#/fahrzeug/' + encodeURIComponent(x.fahrzeug.id) },
            h('span', { class: 'zeile-text' },
              h('strong', { class: 'zeile-name', text: x.aktuell.werte.bezeichnung }),
              h('span', { class: 'zeile-art', text: a.name })),
            schild(a.id, kennungVon(a.id, x.aktuell.werte))));
        })));
      }
      seite('Meine Fahrzeuge', inhalt,
        h('div', { class: 'leiste' }, h('a', { class: 'knopf', href: '#/neu', text: 'Fahrzeug anlegen' })));
    });
  }

  /* ---------- Seite: Fahrzeug mit Schalen ---------- */
  function seiteFahrzeug(id) {
    return daten.fahrzeugLaden(id).then(function (f) {
      if (!f) { return seite('Nicht gefunden', [h('h1', { text: 'Fahrzeug nicht gefunden' }), h('p', null, h('a', { href: '#/', text: 'Zurück zu meinen Fahrzeugen' }))]); }
      var a = MM.Fahrzeugarten.art(f.fahrzeug.art);
      var w = f.aktuell.werte;

      var gruppen = MM.Fahrzeugarten.gruppen(a.id).map(function (g) {
        var gefuellt = [], offen = [];
        g.felder.forEach(function (fe) {
          var t = MM.Hilfen.wert(fe, w[fe.key]);
          if (t === null) offen.push(fe.label); else gefuellt.push([h('dt', { text: fe.label }), h('dd', { text: t })]);
        });
        return h('section', { class: 'gruppe' },
          h('h3', { text: g.titel }),
          gefuellt.length ? h('dl', { class: 'daten' }, gefuellt) : null,
          offen.length ? h('p', { class: 'offen', text: 'Noch nicht angegeben: ' + offen.join(', ') }) : null);
      });

      var s3 = h('section', { class: 'schale s3', 'aria-label': 'Hauptkomponenten' },
        h('div', { class: 'schale-name', text: 'Nächste Schale' }),
        h('h2', { text: 'Hauptkomponenten' }),
        h('p', { text: 'Motor, Getriebe, Heizung, Klima, Stromversorgung und Wasserversorgung kommen im nächsten Schritt. Sie bauen auf der äußeren Hülle auf.' }));

      var s2 = h('section', { class: 'schale s2', 'aria-label': 'Äußere Hülle' },
        h('div', { class: 'schale-kopf' },
          h('div', { class: 'schale-name', text: 'Zweite Schale' }),
          h('h2', { text: 'Äußere Hülle' })),
        gruppen,
        h('p', { class: 'stand', text: 'Stand vom ' + MM.Hilfen.zeitpunkt(f.aktuell.erstelltAm) + ', per Handeingabe' }),
        s3);

      var s1 = h('div', { class: 'schale s1' },
        h('div', { class: 'schale-kopf' },
          h('div', { class: 'schale-name', text: 'Erste Schale: ' + a.name }),
          h('div', { class: 'fahrzeug-kopf' },
            h('h1', { text: w.bezeichnung }),
            schild(a.id, kennungVon(a.id, w)))),
        s2);

      var verlauf = h('details', { class: 'verlauf' },
        h('summary', { text: 'Verlauf der Eintragungen (' + f.verlauf.length + ')' }),
        h('ol', null, f.verlauf.map(function (v, i) {
          var e = v.eintrag;
          var kopfzeile = h('div', null,
            h('span', { class: 'wann', text: MM.Hilfen.zeitpunkt(e.erstelltAm) }),
            i === 0 ? h('span', { class: 'marke-aktuell', text: 'aktuell' }) : null);
          var text;
          if (!v.vorher) text = h('div', { text: 'Angelegt, per Handeingabe' });
          else text = h('div', null,
            h('span', { class: 'korrektur', text: 'Korrektur zu Eintrag vom ' + MM.Hilfen.zeitpunkt(v.vorher.erstelltAm) }),
            h('ul', null, v.aenderungen.map(function (u) {
              var alt = MM.Hilfen.wert(u.feld, u.alt), neu = MM.Hilfen.wert(u.feld, u.neu);
              return h('li', null, u.label + ': ',
                h('span', { class: 'alt', text: alt === null ? 'nicht angegeben' : alt }), ' → ',
                neu === null ? 'nicht angegeben' : neu);
            })));
          return h('li', { class: i === 0 ? 'aktuell' : null }, kopfzeile, text);
        })));

      seite(w.bezeichnung, [
        h('nav', { class: 'krumen', 'aria-label': 'Wo du bist' }, h('a', { href: '#/', text: 'Meine Fahrzeuge' }), ' › ', w.bezeichnung),
        s1, verlauf
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: '#/', text: 'Zur Liste' }),
        h('a', { class: 'knopf', href: '#/fahrzeug/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' })));
    });
  }

  /* ---------- Seite: anlegen / ändern ---------- */
  function feldElement(f, wert, fehler, aenderung) {
    var id = 'f-' + f.key;
    var eingabe;
    if (f.typ === 'auswahl') {
      eingabe = h('select', { id: id, name: f.key, onchange: aenderung },
        h('option', { value: '', text: '– bitte wählen –' }),
        f.optionen.map(function (o) { return h('option', { value: o, text: o }); }));
      eingabe.value = wert || '';
    } else if (f.typ === 'datum') {
      eingabe = h('input', { id: id, name: f.key, type: 'date', value: wert || '', oninput: aenderung });
    } else {
      eingabe = h('input', { id: id, name: f.key, type: 'text', autocomplete: 'off', autocapitalize: f.typ === 'text' ? 'sentences' : 'off',
        inputmode: f.typ === 'zahl' ? 'decimal' : (f.typ === 'ganzzahl' ? 'numeric' : null),
        value: wert === null || wert === undefined ? '' : String(wert).replace('.', f.typ === 'zahl' ? ',' : '.'),
        'aria-describedby': f.hilfe ? id + '-h' : null, 'aria-invalid': fehler ? 'true' : null, oninput: aenderung });
    }
    return h('div', { class: 'feld' + (fehler ? ' hat-fehler' : '') },
      h('label', { for: id, text: f.label }),
      f.hilfe ? h('p', { class: 'hilfe', id: id + '-h', text: f.hilfe }) : null,
      h('div', { class: 'eingabe' }, eingabe, f.einheit ? h('span', { class: 'einheit', text: f.einheit }) : null),
      fehler ? h('p', { class: 'fehler', role: 'alert', text: fehler }) : null);
  }

  function seiteFormular(modus, fahrzeugId) {
    var laden = modus === 'aendern' ? daten.fahrzeugLaden(fahrzeugId) : Promise.resolve(null);
    return laden.then(function (vorhanden) {
      if (modus === 'aendern' && !vorhanden) return seiteFahrzeug(fahrzeugId);
      var zustand = {
        art: vorhanden ? vorhanden.fahrzeug.art : null,
        werte: vorhanden ? Object.assign({}, vorhanden.aktuell.werte) : {},
        fehler: {}
      };
      var titel = modus === 'aendern' ? 'Angaben ändern' : 'Fahrzeug anlegen';
      var behaelter = h('div');

      function lesen() {
        /* Eingaben aus dem Formular in den Zustand übernehmen */
        var felder = behaelter.querySelectorAll('input[name], select[name]');
        Array.prototype.forEach.call(felder, function (el) {
          if (el.type === 'radio') return;
          zustand.werte[el.name] = el.value;
        });
      }

      function speichern(ev) {
        ev.preventDefault();
        lesen();
        var p = modus === 'aendern'
          ? daten.fahrzeugAendern(fahrzeugId, zustand.werte)
          : daten.fahrzeugAnlegen(zustand.art, zustand.werte);
        p.then(function (r) {
          if (!r.ok) {
            zustand.fehler = r.fehler;
            zeichne();
            var ersterFehler = behaelter.querySelector('.hat-fehler input, .hat-fehler select, .fehlerkasten');
            if (ersterFehler) { ersterFehler.focus ? ersterFehler.focus() : null; }
            return;
          }
          meldung = modus === 'aendern'
            ? (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.')
            : 'Fahrzeug angelegt.';
          global.location.hash = '#/fahrzeug/' + encodeURIComponent(r.id);
        }).catch(fehlerSeite);
      }

      function zeichne() {
        behaelter.textContent = '';
        var teile = [];
        if (modus === 'neu' && !zustand.art) {
          teile.push(h('p', { text: 'Wähle zuerst die Fahrzeugart. Dann erscheinen die passenden Felder. Nur die Bezeichnung ist Pflicht.' }));
        }
        var fk = Object.keys(zustand.fehler);
        if (fk.length) {
          teile.push(h('div', { class: 'fehlerkasten', role: 'alert', tabindex: '-1',
            text: fk.length === 1 ? 'Bitte eine Angabe prüfen.' : 'Bitte ' + fk.length + ' Angaben prüfen.' }));
        }

        /* Fahrzeugart: beim Anlegen wählbar, danach fest */
        if (modus === 'neu') {
          teile.push(h('fieldset', { class: 'feld', style: 'border:0;padding:0;margin:0' },
            h('legend', { class: 'fest-art', text: 'Fahrzeugart' }),
            zustand.fehler.art ? h('p', { class: 'fehler', role: 'alert', text: zustand.fehler.art }) : null,
            h('div', { class: 'artwahl' }, MM.Fahrzeugarten.alle().map(function (a) {
              var r = h('input', { type: 'radio', name: 'art', value: a.id, onchange: function () {
                lesen(); zustand.art = a.id; zustand.fehler = {}; zeichne();
                var b = behaelter.querySelector('#f-bezeichnung'); if (b) b.focus({ preventScroll: true });
              } });
              if (zustand.art === a.id) r.checked = true;
              return h('label', { class: 'welt-' + a.welt }, r, h('span', { text: a.name }));
            }))));
        } else {
          teile.push(h('p', null, 'Fahrzeugart: ', h('span', { class: 'fest-art', text: MM.Fahrzeugarten.art(zustand.art).name }),
            h('span', { class: 'hilfe', text: ' (lässt sich nicht ändern)' })));
        }

        if (zustand.art) {
          teile.push(feldElement({ key: 'bezeichnung', label: 'Bezeichnung', typ: 'text', hilfe: 'Wie du das Fahrzeug nennst, zum Beispiel „Fahrzeug A“' },
            zustand.werte.bezeichnung, zustand.fehler.bezeichnung));
          MM.Fahrzeugarten.gruppen(zustand.art).forEach(function (g) {
            teile.push(h('fieldset', { style: 'border:0;padding:0;margin:0;display:grid;gap:1.1rem' },
              h('legend', { class: 'fest-art', text: g.titel, style: 'margin-bottom:.6rem' }),
              g.felder.map(function (f) { return feldElement(f, zustand.werte[f.key], zustand.fehler[f.key]); })));
          });
        }
        anhaengen(behaelter, h('form', { class: 'formular', novalidate: 'novalidate', id: 'formular', onsubmit: speichern }, teile));
      }

      zeichne();
      seite(titel, [
        h('nav', { class: 'krumen' }, h('a', { href: '#/', text: 'Meine Fahrzeuge' }), ' › ', titel),
        h('h1', { text: titel }),
        behaelter
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: modus === 'aendern' ? '#/fahrzeug/' + encodeURIComponent(fahrzeugId) : '#/', text: 'Abbrechen' }),
        h('button', { class: 'knopf', type: 'submit', form: 'formular', text: 'Speichern' })));
    });
  }

  function fehlerSeite(err) {
    wurzel.textContent = '';
    wurzel.appendChild(kopf());
    wurzel.appendChild(h('main', { class: 'fehlerseite' },
      h('h1', { text: 'Das hat nicht geklappt' }),
      h('p', { text: (err && err.message) ? err.message : 'Es ist ein unbekannter Fehler aufgetreten.' }),
      h('p', null, h('a', { class: 'knopf', href: '#/', text: 'Zurück zu meinen Fahrzeugen' }))));
  }

  /* ---------- Weiterleitung nach der Adresse ---------- */
  function zeige() {
    var hash = (global.location.hash || '#/').replace(/^#/, '');
    var teile = hash.split('/').filter(Boolean);
    var p;
    if (teile.length === 0) p = seiteListe();
    else if (teile[0] === 'neu') p = seiteFormular('neu');
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'aendern') p = seiteFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1]) p = seiteFahrzeug(decodeURIComponent(teile[1]));
    else p = seiteListe();
    return p.catch(fehlerSeite);
  }

  function starten(d, el) {
    daten = d; wurzel = el;
    global.addEventListener('hashchange', zeige);
    return zeige();
  }

  MM.Ansicht = { starten: starten, fehler: function (el, err) { wurzel = el; fehlerSeite(err); } };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
