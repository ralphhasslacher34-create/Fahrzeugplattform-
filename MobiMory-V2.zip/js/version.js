/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.1';
  MM.STUFE = 'Schritt 1: Fahrzeug, Schale 1 und 2';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
