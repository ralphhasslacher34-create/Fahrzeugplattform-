/* Start: Speicher öffnen, Daten starten, erste Seite zeigen. */
(function (global) {
  'use strict';
  var MM = global.MM;
  var el = global.document.getElementById('app');

  new MM.Speicher.IdbSpeicher().oeffnen()
    .then(function (speicher) {
      var daten = new MM.Daten.Daten(speicher);
      return daten.starten().then(function () { return MM.Ansicht.starten(daten, el); });
    })
    .catch(function (err) { MM.Ansicht.fehler(el, err); });

  /* Die Daten sollen auf dem Gerät bleiben, auch wenn der Speicher knapp wird. */
  if (global.navigator.storage && global.navigator.storage.persist) {
    global.navigator.storage.persist().catch(function () {});
  }

  /* Offline-Betrieb: nur über https oder localhost möglich. */
  if ('serviceWorker' in global.navigator && /^https?:$/.test(global.location.protocol)) {
    global.addEventListener('load', function () {
      global.navigator.serviceWorker.register('sw.js').catch(function () {});
    });
  }
})(window);
