/*
 * Speicher: der Ort, an dem die Daten auf dem Gerät liegen.
 *
 * Es gibt zwei Ausführungen mit denselben Aufrufen:
 *  - IdbSpeicher: der echte Speicher im Gerät (IndexedDB), funktioniert offline
 *  - MemorySpeicher: nur für die automatischen Tests
 *
 * Alle anderen Teile der App sprechen nur mit Daten (daten.js) und nie
 * direkt mit dem Speicher. Das ist die "eine Tür". Kommt später der Server
 * dazu, wird hier ein weiterer Speicher mit denselben Aufrufen ergänzt.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var TABELLEN = ['datenraeume', 'fahrzeuge', 'eintraege'];

  function klon(o) { return JSON.parse(JSON.stringify(o)); }

  /* ---- Speicher nur im Arbeitsspeicher (Tests) ---- */
  function MemorySpeicher() {
    this.t = {};
    TABELLEN.forEach(function (n) { this.t[n] = {}; }, this);
  }
  MemorySpeicher.prototype.alle = function (tabelle) {
    var t = this.t[tabelle];
    return Promise.resolve(Object.keys(t).map(function (k) { return klon(t[k]); }));
  };
  MemorySpeicher.prototype.holen = function (tabelle, id) {
    var o = this.t[tabelle][id];
    return Promise.resolve(o ? klon(o) : null);
  };
  MemorySpeicher.prototype.speichern = function (tabelle, objekt) {
    this.t[tabelle][objekt.id] = klon(objekt);
    return Promise.resolve();
  };
  MemorySpeicher.prototype.mehrereSpeichern = function (liste) {
    liste.forEach(function (e) { this.t[e.tabelle][e.objekt.id] = klon(e.objekt); }, this);
    return Promise.resolve();
  };
  MemorySpeicher.prototype.wo = function (tabelle, feld, wert) {
    return this.alle(tabelle).then(function (l) {
      return l.filter(function (o) { return o[feld] === wert; });
    });
  };
  MemorySpeicher.prototype.allesLoeschen = function () {
    TABELLEN.forEach(function (n) { this.t[n] = {}; }, this);
    return Promise.resolve();
  };

  /* ---- Speicher im Gerät (IndexedDB) ---- */
  function IdbSpeicher(name) {
    this.name = name || 'mobimory-v2';
    this.db = null;
  }
  IdbSpeicher.prototype.oeffnen = function () {
    var self = this;
    return new Promise(function (ok, fehler) {
      if (typeof indexedDB === 'undefined') {
        fehler(new Error('Dieses Gerät oder dieser Browser kann keine Daten speichern.'));
        return;
      }
      /* Datenbank-Version 1. Spätere Änderungen kommen als neue Version
         mit eigener Umstellung, damit vorhandene Daten erhalten bleiben. */
      var anfrage = indexedDB.open(self.name, 1);
      anfrage.onupgradeneeded = function () {
        var db = anfrage.result;
        db.createObjectStore('datenraeume', { keyPath: 'id' });
        db.createObjectStore('fahrzeuge', { keyPath: 'id' });
        var e = db.createObjectStore('eintraege', { keyPath: 'id' });
        e.createIndex('fahrzeugId', 'fahrzeugId');
      };
      anfrage.onsuccess = function () { self.db = anfrage.result; ok(self); };
      anfrage.onerror = function () { fehler(anfrage.error || new Error('Speicher konnte nicht geöffnet werden.')); };
      anfrage.onblocked = function () { fehler(new Error('Der Speicher ist durch ein anderes Fenster blockiert. Bitte andere MobiMory-Fenster schließen.')); };
    });
  };
  function warten(anfrage) {
    return new Promise(function (ok, fehler) {
      anfrage.onsuccess = function () { ok(anfrage.result); };
      anfrage.onerror = function () { fehler(anfrage.error); };
    });
  }
  IdbSpeicher.prototype.alle = function (tabelle) {
    return warten(this.db.transaction(tabelle).objectStore(tabelle).getAll());
  };
  IdbSpeicher.prototype.holen = function (tabelle, id) {
    return warten(this.db.transaction(tabelle).objectStore(tabelle).get(id)).then(function (o) { return o || null; });
  };
  IdbSpeicher.prototype.speichern = function (tabelle, objekt) {
    return this.mehrereSpeichern([{ tabelle: tabelle, objekt: objekt }]);
  };
  IdbSpeicher.prototype.mehrereSpeichern = function (liste) {
    var db = this.db;
    return new Promise(function (ok, fehler) {
      var namen = liste.map(function (e) { return e.tabelle; })
        .filter(function (n, i, a) { return a.indexOf(n) === i; });
      var tx = db.transaction(namen, 'readwrite');
      liste.forEach(function (e) { tx.objectStore(e.tabelle).put(e.objekt); });
      tx.oncomplete = function () { ok(); };
      tx.onerror = function () { fehler(tx.error); };
      tx.onabort = function () { fehler(tx.error || new Error('Speichern abgebrochen.')); };
    });
  };
  IdbSpeicher.prototype.wo = function (tabelle, feld, wert) {
    var store = this.db.transaction(tabelle).objectStore(tabelle);
    if (store.indexNames.contains(feld)) { return warten(store.index(feld).getAll(wert)); }
    return this.alle(tabelle).then(function (l) { return l.filter(function (o) { return o[feld] === wert; }); });
  };
  IdbSpeicher.prototype.allesLoeschen = function () {
    var db = this.db;
    return new Promise(function (ok, fehler) {
      var tx = db.transaction(TABELLEN, 'readwrite');
      TABELLEN.forEach(function (n) { tx.objectStore(n).clear(); });
      tx.oncomplete = function () { ok(); };
      tx.onerror = function () { fehler(tx.error); };
    });
  };

  MM.Speicher = { MemorySpeicher: MemorySpeicher, IdbSpeicher: IdbSpeicher };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
